import flet as ft
from views.catalogue import CatalogueView
# from views.record import DetailView

def main(page: ft.Page):
    page.title = "WIS2 Catalogue"

    def route_change(route):
        page.views.clear()
        page.views.append(CatalogueView(page))
        print(f"Navigated to {page.route}")
        # if page.route == "/details":
        #     page.views.append(DetailView(page))
        
        page.update()

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)

    page.views.append(CatalogueView(page))
    page.on_route_change = route_change
    page.on_view_pop = view_pop
    
    # Start at root
    page.go(page.route)
    page.update()

print("Starting Flet app...")

ft.run(main, view=ft.AppView.WEB_BROWSER)